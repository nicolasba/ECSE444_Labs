#ifndef _STDEV_H
#define _STDEV_H

	void c_stdev(float *f_arr, int N, float *stdev);
	void asm_stdev(float *f_arr, int N, float *stdev);

#endif
