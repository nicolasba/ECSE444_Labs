#ifndef _MULT_ARRAY_H
#define _MULT_ARRAY_H

	void c_mult_array(float *f_arr_a, float *f_arr_b, float *f_res, int N);
	void asm_mult_array(float *f_arr_a, float *f_arr_b, float *f_res, int N);

#endif
